/*
var arabic = document.getElementById("ar"),
    english = document.getElementById("en");
arabic.onclick = function () {

    document.body.classList.add('direction:rtl')

}
english.onclick = function () {

    document.body.classList.add("en");
    document.body.classList.remove("ar")

}
arabic.onclick = function () {

    document.body.classList.add("ar");
    document.body.classList.add("en");
}
*/
/*
var nav11 = document.getElementById("nav1"),
    nav22 = document.getElementById("nav2"),
    nav33 = document.getElementById("nav3");

nav11.onclick = function () {
    nav11.classList.add("active");
    nav22.classList.remove("active");
    nav33.classList.remove("active");
}
nav22.onclick = function () {
    nav22.classList.add("active");
    nav11.classList.remove("active");
    nav33.classList.remove("active");
}
nav33.onclick = function () {
    nav33.classList.add("active");
    nav22.classList.remove("active");
    nav11.classList.remove("active");
}    
*/

// document.getElementById("super1").onkeyup = function sProcuct1() {
//     "use strict";

//     var input = document.getElementById("super1").value,
//         result = input * 85,
//         final = document.getElementById("superMassage1");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// var input2 = document.getElementById("super2").value,
//     result2 = input2 * 100,
//     final2 = document.getElementById("superMassage2");
// document.getElementById("super2").onkeyup = function sProcuct2() {
//     "use strict";

//     var input2 = document.getElementById("super2").value,
//         result2 = input2 * 100,
//         final2 = document.getElementById("superMassage2");


//     if (input2 === "") {
//         final2.value = "×";

//     } else if (isNaN(input2)) {
//         final2.value = "×";

//     } else if (input2 < 0) {
//         final2.value = "×";

//     } else if (input2 === "0") {
//         final2.value = "0";

//     } else {
//         final2.value = result2;

//     }
// }

// var input3 = document.getElementById("super3").value,
//     result3 = input3 * 75,
//     final3 = document.getElementById("superMassage3");


// document.getElementById("super3").onkeyup = function sProcuct3() {
//     "use strict";
//     var input3 = document.getElementById("super3").value,
//         result3 = input3 * 75,
//         final3 = document.getElementById("superMassage3");


//     if (input3 === "") {
//         final3.value = "×";

//     } else if (isNaN(input3)) {
//         final3.value = "×";

//     } else if (input3 < 0) {
//         final3.value = "×";

//     } else if (input3 === "0") {
//         final3.value = "0";

//     } else {
//         final3.value = result3;

//     }
// }
// document.getElementById("super4").onkeyup = function sProcuct4() {
//     "use strict";

//     var input = document.getElementById("super4").value,
//         result = input * 80,
//         final = document.getElementById("superMassage4");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super5").onkeyup = function sProcuct5() {
//     "use strict";

//     var input = document.getElementById("super5").value,
//         result = input * 85,
//         final = document.getElementById("superMassage5");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super6").onkeyup = function sProcuct6() {
//     "use strict";

//     var input = document.getElementById("super6").value,
//         result = input * 85,
//         final = document.getElementById("superMassage6");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super7").onkeyup = function sProcuct7() {
//     "use strict";

//     var input = document.getElementById("super7").value,
//         result = input * 85,
//         final = document.getElementById("superMassage7");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super8").onkeyup = function sProcuct8() {
//     "use strict";

//     var input = document.getElementById("super8").value,
//         result = input * 100,
//         final = document.getElementById("superMassage8");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super9").onkeyup = function sProcuct9() {
//     "use strict";

//     var input = document.getElementById("super9").value,
//         result = input * 100,
//         final = document.getElementById("superMassage9");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super10").onkeyup = function sProcuct10() {
//     "use strict";

//     var input = document.getElementById("super10").value,
//         result = input * 65,
//         final = document.getElementById("superMassage10");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super11").onkeyup = function sProcuct11() {
//     "use strict";

//     var input = document.getElementById("super11").value,
//         result = input * 65,
//         final = document.getElementById("superMassage11");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super12").onkeyup = function sProcuct12() {
//     "use strict";

//     var input = document.getElementById("super12").value,
//         result = input * 70,
//         final = document.getElementById("superMassage12");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super13").onkeyup = function sProcuct13() {
//     "use strict";

//     var input = document.getElementById("super13").value,
//         result = input * 75,
//         final = document.getElementById("superMassage13");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super14").onkeyup = function sProcuct14() {
//     "use strict";

//     var input = document.getElementById("super14").value,
//         result = input * 80,
//         final = document.getElementById("superMassage14");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super15").onkeyup = function sProcuct15() {
//     "use strict";

//     var input = document.getElementById("super15").value,
//         result = input * 85,
//         final = document.getElementById("superMassage15");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super16").onkeyup = function sProcuct16() {
//     "use strict";

//     var input = document.getElementById("super16").value,
//         result = input * 85,
//         final = document.getElementById("superMassage16");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super17").onkeyup = function sProcuct17() {
//     "use strict";

//     var input = document.getElementById("super17").value,
//         result = input * 90,
//         final = document.getElementById("superMassage17");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super18").onkeyup = function sProcuct18() {
//     "use strict";

//     var input = document.getElementById("super18").value,
//         result = input * 95,
//         final = document.getElementById("superMassage18");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }

// document.getElementById("super19").onkeyup = function sProcuct19() {
//     "use strict";

//     var input = document.getElementById("super19").value,
//         result = input * 80,
//         final = document.getElementById("superMassage19");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }

// document.getElementById("super20").onkeyup = function sProcuct20() {
//     "use strict";

//     var input2 = document.getElementById("super20").value,
//         result2 = input2 * 85,
//         final2 = document.getElementById("superMassage20");


//     if (input2 === "") {
//         final2.value = "×";

//     } else if (isNaN(input2)) {
//         final2.value = "×";

//     } else if (input2 < 0) {
//         final2.value = "×";

//     } else if (input2 === "0") {
//         final2.value = "0";

//     } else {
//         final2.value = result2;

//     }
// }




// document.getElementById("super21").onkeyup = function sProcuct21() {
//     "use strict";
//     var input3 = document.getElementById("super21").value,
//         result3 = input3 * 90,
//         final3 = document.getElementById("superMassage21");


//     if (input3 === "") {
//         final3.value = "×";

//     } else if (isNaN(input3)) {
//         final3.value = "×";

//     } else if (input3 < 0) {
//         final3.value = "×";

//     } else if (input3 === "0") {
//         final3.value = "0";

//     } else {
//         final3.value = result3;

//     }
// }
// document.getElementById("super22").onkeyup = function sProcuct22() {
//     "use strict";

//     var input = document.getElementById("super22").value,
//         result = input * 65,
//         final = document.getElementById("superMassage22");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super23").onkeyup = function sProcuct23() {
//     "use strict";

//     var input = document.getElementById("super23").value,
//         result = input * 75,
//         final = document.getElementById("superMassage23");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super24").onkeyup = function sProcuct24() {
//     "use strict";

//     var input = document.getElementById("super24").value,
//         result = input * 75,
//         final = document.getElementById("superMassage24");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super25").onkeyup = function sProcuct25() {
//     "use strict";

//     var input = document.getElementById("super25").value,
//         result = input * 80,
//         final = document.getElementById("superMassage25");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super26").onkeyup = function sProcuct26() {
//     "use strict";

//     var input = document.getElementById("super26").value,
//         result = input * 75,
//         final = document.getElementById("superMassage26");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super27").onkeyup = function sProcuct27() {
//     "use strict";

//     var input = document.getElementById("super27").value,
//         result = input * 85,
//         final = document.getElementById("superMassage27");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super28").onkeyup = function sProcuct28() {
//     "use strict";

//     var input = document.getElementById("super28").value,
//         result = input * 90,
//         final = document.getElementById("superMassage28");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super29").onkeyup = function sProcuct29() {
//     "use strict";

//     var input = document.getElementById("super29").value,
//         result = input * 140,
//         final = document.getElementById("superMassage29");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super30").onkeyup = function sProcuct30() {
//     "use strict";

//     var input = document.getElementById("super30").value,
//         result = input * 150,
//         final = document.getElementById("superMassage30");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super31").onkeyup = function sProcuct31() {
//     "use strict";

//     var input = document.getElementById("super31").value,
//         result = input * 45,
//         final = document.getElementById("superMassage31");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super32").onkeyup = function sProcuct32() {
//     "use strict";

//     var input = document.getElementById("super32").value,
//         result = input * 200,
//         final = document.getElementById("superMassage32");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super33").onkeyup = function sProcuct33() {
//     "use strict";

//     var input = document.getElementById("super33").value,
//         result = input * 200,
//         final = document.getElementById("superMassage33");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super34").onkeyup = function sProcuct34() {
//     "use strict";

//     var input = document.getElementById("super34").value,
//         result = input * 240,
//         final = document.getElementById("superMassage34");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super35").onkeyup = function sProcuct35() {
//     "use strict";

//     var input = document.getElementById("super35").value,
//         result = input * 100,
//         final = document.getElementById("superMassage35");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super36").onkeyup = function sProcuct36() {
//     "use strict";

//     var input = document.getElementById("super36").value,
//         result = input * 240,
//         final = document.getElementById("superMassage36");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super37").onkeyup = function sProcuct37() {
//     "use strict";

//     var input = document.getElementById("super37").value,
//         result = input * 240,
//         final = document.getElementById("superMassage37");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super38").onkeyup = function sProcuct38() {
//     "use strict";

//     var input = document.getElementById("super38").value,
//         result = input * 350,
//         final = document.getElementById("superMassage38");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super39").onkeyup = function sProcuct39() {
//     "use strict";

//     var input = document.getElementById("super39").value,
//         result = input * 450,
//         final = document.getElementById("superMassage39");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super40").onkeyup = function sProcuct40() {
//     "use strict";

//     var input = document.getElementById("super40").value,
//         result = input * 215,
//         final = document.getElementById("superMassage40");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super41").onkeyup = function sProcuct41() {
//     "use strict";

//     var input = document.getElementById("super41").value,
//         result = input * 7,
//         final = document.getElementById("superMassage41");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super42").onkeyup = function sProcuct42() {
//     "use strict";

//     var input = document.getElementById("super42").value,
//         result = input * 2300,
//         final = document.getElementById("superMassage42");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }
// document.getElementById("super43").onkeyup = function sProcuct43() {
//     "use strict";

//     var input = document.getElementById("super43").value,
//         result = input * 2500,
//         final = document.getElementById("superMassage43");


//     if (input === "") {
//         final.value = "×";

//     } else if (isNaN(input)) {
//         final.value = "×";

//     } else if (input < 0) {
//         final.value = "×";

//     } else if (input === "0") {
//         final.value = "0";

//     } else {
//         final.value = result;
//     }
// }

// document.getElementById("clear").onclick = function c() {
//     document.getElementById("super3").value = '';
//     document.getElementById("super2").value = '';
//     document.getElementById("super1").value = '';
//     document.getElementById("super4").value = '';
//     document.getElementById("super5").value = '';
//     document.getElementById("super6").value = '';
//     document.getElementById("super7").value = '';
//     document.getElementById("super8").value = '';
//     document.getElementById("super9").value = '';
//     document.getElementById("super10").value = '';
//     document.getElementById("super11").value = '';
//     document.getElementById("super12").value = '';
//     document.getElementById("super13").value = '';
//     document.getElementById("super14").value = '';
//     document.getElementById("super15").value = '';
//     document.getElementById("super16").value = '';
//     document.getElementById("super17").value = '';
//     document.getElementById("super18").value = '';
//     document.getElementById("super19").value = '';
//     document.getElementById("super20").value = '';
//     document.getElementById("super21").value = '';
//     document.getElementById("super22").value = '';
//     document.getElementById("super23").value = '';
//     document.getElementById("super24").value = '';
//     document.getElementById("super25").value = '';
//     document.getElementById("super26").value = '';
//     document.getElementById("super27").value = '';
//     document.getElementById("super28").value = '';
//     document.getElementById("super29").value = '';
//     document.getElementById("super30").value = '';
//     document.getElementById("super31").value = '';
//     document.getElementById("super32").value = '';
//     document.getElementById("super33").value = '';
//     document.getElementById("super34").value = '';
//     document.getElementById("super35").value = '';
//     document.getElementById("super36").value = '';
//     document.getElementById("super37").value = '';
//     document.getElementById("super38").value = '';
//     document.getElementById("super39").value = '';
//     document.getElementById("super40").value = '';
//     document.getElementById("super41").value = '';
//     document.getElementById("super42").value = '';
//     document.getElementById("super43").value = '';

//     document.getElementById("superMassage1").value = '';
//     document.getElementById("superMassage2").value = '';
//     document.getElementById("superMassage3").value = '';
//     document.getElementById("superMassage4").value = '';
//     document.getElementById("superMassage5").value = '';
//     document.getElementById("superMassage6").value = '';
//     document.getElementById("superMassage7").value = '';
//     document.getElementById("superMassage8").value = '';
//     document.getElementById("superMassage9").value = '';
//     document.getElementById("superMassage10").value = '';
//     document.getElementById("superMassage11").value = '';
//     document.getElementById("superMassage12").value = '';
//     document.getElementById("superMassage13").value = '';
//     document.getElementById("superMassage14").value = '';
//     document.getElementById("superMassage15").value = '';
//     document.getElementById("superMassage16").value = '';
//     document.getElementById("superMassage17").value = '';
//     document.getElementById("superMassage18").value = '';
//     document.getElementById("superMassage19").value = '';
//     document.getElementById("superMassage20").value = '';
//     document.getElementById("superMassage21").value = '';
//     document.getElementById("superMassage22").value = '';
//     document.getElementById("superMassage23").value = '';
//     document.getElementById("superMassage24").value = '';
//     document.getElementById("superMassage25").value = '';
//     document.getElementById("superMassage26").value = '';
//     document.getElementById("superMassage27").value = '';
//     document.getElementById("superMassage28").value = '';
//     document.getElementById("superMassage29").value = '';
//     document.getElementById("superMassage30").value = '';
//     document.getElementById("superMassage31").value = '';
//     document.getElementById("superMassage32").value = '';
//     document.getElementById("superMassage33").value = '';
//     document.getElementById("superMassage34").value = '';
//     document.getElementById("superMassage35").value = '';
//     document.getElementById("superMassage36").value = '';
//     document.getElementById("superMassage37").value = '';
//     document.getElementById("superMassage38").value = '';
//     document.getElementById("superMassage39").value = '';
//     document.getElementById("superMassage40").value = '';
//     document.getElementById("superMassage41").value = '';
//     document.getElementById("superMassage42").value = '';
//     document.getElementById("superMassage43").value = '';

//     resultValue.value = '';
// }




// function findTotal(){
//     var arr = document.getElementsByName('superMassage');
//     var tot=0;
//     for(var i=0;i<arr.length;i++){
//         if(parseInt(arr[i].value))
//             tot += parseInt(arr[i].value);
//     }
//     document.getElementById('total').value = tot;
// }

// document.getElementById("suggitionButton").onclick = function sProcuct11() {
//     "use strict";

//     var input = document.getElementById("suggitionInput").value,
//         output = document.getElementById("suggitionOutput");


//     if (input === "") {
//         output.innerHTML = "×";

//     } else if (isNaN(input)) {
//         output.innerHTML = "×";

//     } else if (input < 0) {
//         output.innerHTML = "×";

//     } else if (input === "0") {
//         output.innerHTML = "0";

//     } else if (input > 0 & input <= 57) {
//         output.innerHTML = "لا يمكن تركيب اي قائم";
    
//     }
//     else if (input > 57 & input <= 77 ) {
//         output.innerHTML = "يمكن تركيب 2 قائم بينهم 50 سم";
    
//     }
//     else if (input > 77 & input <= 104) {
//         output.innerHTML = "يمكن تركيب 2 قائم بينهم 70 سم";
    
//     }
//     else if (input > 104 & input <= 127) {
//         output.innerHTML = "يمكن تركيب 2 قائم بينهم 100 سم";
    
//     }
//     else if (input > 127 & input <= 147) {
//         output.innerHTML = "يمكن تركيب 3 قائم بينهم 70سم و 50 سم";
    
//     }
//     else if (input > 147 & input <= 153) {
//         output.innerHTML = "يمكن تركيب 3 قائم بينهم 70 سم و 70 سم";
    
//     }else if (input > 153 & input <= 173) {
//         output.innerHTML = "يمكن تركيب 3 قائم بينهم 100 سم و 50 سم";
    
//     }else if (input > 173 & input <= 199) {
//         output.innerHTML = "يمكن تركيب 3 قائم بينهم 100 سم و 70 سم";
    
//     }else if (input > 199 & input <= 223) {
//         output.innerHTML = "يمكن تركيب 3 قائم بينهم 100 سم و 100 سم";
    
//     }else if (input > 223 & input <= 243) {
//         output.innerHTML = "يمكن تركيب 4 قائم بينهم 100 سم و 70 سم و 50 سم";
    
//     }else if (input > 243 & input <= 249) {
//         output.innerHTML = "يمكن تركيب  4 قائم بينهم 100 سم و 70 سم و 70 سم";
    
//     }else if (input > 249 & input <= 269) {
//         output.innerHTML = "يمكن تركيب 4 قائم بينهم 100 سم و 100 سم و 50 سم";
    
//     }else if (input > 269 & input <= 287) {
//         output.innerHTML = "يمكن تركيب 4 قائم بينهم 100 سم و 100 سم و 70 سم";
    
//     }else if (input > 288 & input <= 319) {
//         output.innerHTML = "يمكن تركيب 4 قائم بينهم 100 سم و 100 سم و 100 سم";
    
//     }else if (input > 319 & input <= 339) {
//         output.innerHTML = "يمكن تركيب 5 قائم بينهم 100سم و 100سم و 70سم و 50سم";
    
//     }else if (input > 339 & input <= 345) {
//         output.innerHTML = "يمكن تركيب  5 قائم بينهم 100سم و 100سم و 70سم و 70سم";
    
//     }else if (input > 345 & input <= 365) {
//         output.innerHTML = "يمكن تركيب 5 قائم بينهم 100سم و 100سم و 100سم و 50سم";
    
//     }else if (input > 365 & input <= 391) {
//         output.innerHTML = "يمكن تركيب 5 قائم بينهم 100سم و 100سم و 100سم و 70سم";
    
//     }else if (input > 391 & input <= 415) {
//         output.innerHTML = "يمكن تركيب 5 قائم بينهم 100سم و 100سم و 100سم و 100سم";
    
//     }else if (input > 415 & input <= 435) {
//         output.innerHTML = "يمكن تركيب 6 قائم بينهم 100سم و 100سم و 100سم و 70سم و 50سم";
    
//     }else if (input > 435 & input <= 441) {
//         output.innerHTML = "يمكن تركيب  6 قائم بينهم 100سم و 100سم و 100سم و 70سم و 70سم";
    
//     }else if (input > 441 & input <= 461) {
//         output.innerHTML = "يمكن تركيب 6 قائم بينهم 100سم و 100سم و 100سم و 100سم و 50سم";
    
//     }else if (input > 461 & input <= 487) {
//         output.innerHTML = "يمكن تركيب 6 قائم بينهم 100سم و 100سم و 100سم و 100سم و 70سم";
    
//     }else if (input > 487 & input <= 511) {
//         output.innerHTML = "يمكن تركيب 6 قائم بينهم 100سم و 100سم و 100سم و 100سم و 100سم";
    
//     }else if (input > 511 & input <= 531) {
//         output.innerHTML = "يمكن تركيب 7 قائم بينهم 100سم و 100سم و 100سم و100سم و 70سم و 50سم";
    
//     }else if (input > 531 & input <= 537) {
//         output.innerHTML = "يمكن تركيب  7 قائم بينهم 100سم و 100سم و 100سم و 100سم و 70سم و 70سم";
    
//     }else if (input > 537 & input <= 557) {
//         output.innerHTML = "يمكن تركيب 7 قائم بينهم 100سم و 100سم و 100سم و 100سم و 100سم و 50سم";
    
//     }else if (input > 557 & input <= 583) {
//         output.innerHTML = "يمكن تركيب 7 قائم بينهم 100سم و 100سم و 100سم و 100سم و 100سم و 70سم";
    
//     }else if (input > 583 & input <= 600) {
//         output.innerHTML = "يمكن تركيب 7 قائم بينهم 100سم و 100سم و 100سم و 100سم و 100سم و 100سم";
//     }else {
//         output.innerHTML = "لم يحدد بعد";
//     }

// }

// document.getElementById("ShelfStanndCalcButton").onclick = function () {
//     document.getElementById("ShelfStanndCalc").value = (document.getElementById("SstandsNumber").value - 1) * document.getElementById("SshelfsNumber").value;
// }


window.addEventListener("scroll", function () {
    var nav = document.querySelector("nav");
    nav.classList.toggle("sticky", window.scrollY > 20);
});

// document.getElementById("wood-calc-Button").onclick = function () {
// document.getElementById("wood-result").value = (parseInt(document.getElementById("wood-width").value) *  parseInt(document.getElementById("wood-height").value)) / 3;
// }
window.addEventListener('scroll', () => {
    const arr = document.querySelector('.arrow-bg');
    arr.classList.toggle('arrow-show', window.scrollY > 20)
    });

